module.exports = {
    secret: 'Azkaban'
};